//
//  map.swift
//  den
//
//  Created by Emir Bayram on 9.10.2021.
//

import SwiftUI

struct map: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct map_Previews: PreviewProvider {
    static var previews: some View {
        map()
    }
}
