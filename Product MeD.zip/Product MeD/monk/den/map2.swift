//  map2.swift
//  MeDaily Reminder Version 1.0
//  Created by Emir Bayram on 01.06.2021.
//
import UIKit
import MapKit

class MapVC: UIViewController {
    
    @IBOutlet var mapView: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let pharmacy1 = MKPointAnnotation()
        pharmacy1.coordinate = CLLocationCoordinate2D(latitude: 41.087853, longitude: 29.014096)
        pharmacy1.title = "Omur Pharmacy"
        pharmacy1.subtitle = "100 meters away"
        mapView.addAnnotation(pharmacy1)
        
        let pharmacy2 = MKPointAnnotation()
        pharmacy2.coordinate = CLLocationCoordinate2D(latitude: 41.086059, longitude: 29.008232)
        pharmacy2.title = "Emre Pharmacy"
        pharmacy2.subtitle = "400 meters away"
        mapView.addAnnotation(pharmacy2)
        
        let pharmacy3 = MKPointAnnotation()
        pharmacy3.coordinate = CLLocationCoordinate2D(latitude: 41.086854, longitude: 29.007683)
        pharmacy3.title = "Arzu Pharmacy"
        pharmacy3.subtitle = "450 meters away"
        mapView.addAnnotation(pharmacy3)
        
        let randomLocation = MKPointAnnotation()
        randomLocation.coordinate = CLLocationCoordinate2D(latitude: 41.087338, longitude: 29.010724)
        
        let yourLocation = MKPointAnnotation()
        yourLocation.coordinate = CLLocationCoordinate2D(latitude: 41.088154, longitude: 29.015615)
        yourLocation.title = "Your Location"
        mapView.addAnnotation(yourLocation)
        
        let region = MKCoordinateRegion(center: randomLocation.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
        mapView.setRegion(region, animated: true)
    }
}
