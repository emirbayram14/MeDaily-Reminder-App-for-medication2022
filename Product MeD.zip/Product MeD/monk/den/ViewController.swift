//
//  ViewController.swift
//  MeDaily Reminder Version 1.0
//
//  Created by Emir Bayram on 01.06.2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var welcomeLabel: UILabel!
    @IBOutlet var usernameField: UITextField!
    @IBOutlet var passwordField: UITextField!
    @IBOutlet var signinButton: UIButton!
    
  
    override func viewDidLoad() {
        super.viewDidLoad()
            
        }
    
    @IBAction func signinGo(_ sender: UIButton) {
        
    }
}

class MainMenuVC: UIViewController {
    
    
    @IBOutlet var newButton: UIButton!
    @IBOutlet var medicineButton: UIButton!
    @IBOutlet var statisticsButton: UIButton!
    @IBOutlet var calendarButton: UIButton!
    @IBOutlet var settingsButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    
    }

}

class SettingsVC: UIViewController {
    
    @IBOutlet var compInfoLabel: UILabel!
    @IBOutlet var compUsernameField: UITextField!
    @IBOutlet var compPasswordField: UITextField!
    @IBOutlet var compSaveButton: UIButton!
    @IBOutlet var goBackSettingsButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    
    }
    
}

class CalendarVC: UIViewController {
    @IBOutlet var cal1Label: UILabel!
    @IBOutlet var cal1View: UIImageView!
    @IBOutlet var cal2Label: UILabel!
    @IBOutlet var cal2View: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
    
    }

}

class StatisticsVC: UIViewController {
    
    @IBOutlet var dailyButton: UIButton!
    @IBOutlet var weeklyButton: UIButton!
    @IBOutlet var monthlyButton: UIButton!
    @IBOutlet var shareButton: UIButton!
    @IBOutlet var goBackStatisticsButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    }

}

class MedicineVC: UIViewController {
    @IBOutlet var med1Label: UILabel!
    @IBOutlet var med2LAbel: UILabel!
    @IBOutlet var med3Label: UILabel!
    @IBOutlet var med4Label: UILabel!
    @IBOutlet var med5Label: UILabel!
    @IBOutlet var med1Text: UITextView!
    @IBOutlet var med2Text: UITextView!
    @IBOutlet var med3Text: UITextView!
    @IBOutlet var med4Text: UITextView!
    @IBOutlet var med5Text: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
    
    }
    
}

class NewEntryVC: UIViewController {
    
    @IBOutlet var nameField: UITextField!
    @IBOutlet var typeField: UITextField!
    @IBOutlet var amountPerDoseField: UITextField!
    @IBOutlet var frequencyField: UITextField!
    @IBOutlet var strengthField: UITextField!
    @IBOutlet var mealField: UITextField!
    @IBOutlet var morningNextButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
}


import UserNotifications

class morningNotificationsVC: UIViewController{
    
    @IBOutlet var morningNotificationTitleField: UITextField!
    @IBOutlet var morningNotificationMessageField: UITextField!
    @IBOutlet var morningNotificationDatePicker: UIDatePicker!
    
    let notificationCenter = UNUserNotificationCenter.current()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        notificationCenter.requestAuthorization(options: [.alert, .sound]) { (permissionGranted, error) in
            if(!permissionGranted){
                print("Permission denied.")
            }
        }
       
    }
    
    
    @IBAction func morningSaveAction(_ sender: Any) {
        notificationCenter.getNotificationSettings { (settings) in
            
            DispatchQueue.main.async
            {
                let title = self.morningNotificationTitleField.text!
                let message = self.morningNotificationMessageField.text!
                let date = self.morningNotificationDatePicker.date
                if(settings.authorizationStatus == .authorized) {
                    let content = UNMutableNotificationContent()
                    content.title = title
                    content.body = message
                    
                    let dateComp = Calendar.current.dateComponents([.year,.month,.day,.hour,.minute], from: date)
                    let trigger = UNCalendarNotificationTrigger(dateMatching: dateComp, repeats: false)
                    let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
                    
                    self.notificationCenter.add(request) { (error) in
                        if(error != nil)
                        {
                            print("Error " + error.debugDescription)
                            return
                        }
                    }
                    let ac = UIAlertController(title: "Notification Scheduled", message: "At " + self.formattedDate(date: date), preferredStyle: .alert)
                    ac.addAction(UIAlertAction(title: "OK", style: .default, handler: { (_) in}))
                    self.present(ac, animated: true)
                        
                        
                }
                else
                {
                    let ac = UIAlertController(title: "Enable Notifications?", message: "To use this feature you must enable notifications in settings ", preferredStyle: .alert)
                    let goToSettings = UIAlertAction(title: "Settings", style: .default) { (_) in
                        guard let settingsURL = URL(string: UIApplication.openSettingsURLString)
                        else
                        {
                            return
                        }
                        
                        if(UIApplication.shared.canOpenURL(settingsURL))
                        {
                            
                            UIApplication.shared.open(settingsURL) { (_) in}
                        }
                    
                    }
                    ac.addAction(goToSettings)
                    ac.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (_) in}))
                    self.present(ac, animated: true)
                    
            }

            }
        }
        
        
    }
    
    func formattedDate(date: Date) -> String
    {
        let formatter = DateFormatter()
        formatter.dateFormat = "d MMM y HH:mm"
        return formatter.string(from: date)
    }
    
}
 



import PDFKit

class DailyReportVC: UIViewController {
    
    let pdfView = PDFView()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(pdfView)
        
        
        
        guard let url = Bundle.main.url(forResource: "DMR", withExtension: "pdf") else {
            return
        }
    
    guard let document = PDFDocument(url: url) else {
        return
    }
    
    
        pdfView.document = document

    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        pdfView.frame = view.bounds
            
        
        
    }
    

}
